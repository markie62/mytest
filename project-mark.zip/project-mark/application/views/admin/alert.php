
<style type="text/css">


	body.csoon{	
		background: #fff  url('../public/assets/img/soon.jpg');
		background-repeat: no-repeat;
	  	background-position: center;
	  	background-attachment: fixed;
	  	overflow: hidden;
	  	background-position-y: 80%;
	}
	.soontext{
		padding-top: 3%;

	}
</style>

<body class="csoon">
	<div class="soontext">
		<h3>
		Comming soon ...
		</h3>
</div>
</body>



<?php $this->load->view($page); ?>	


<?php echo $error;?>

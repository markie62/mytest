<title><?php echo $title;?></title>
<p>FRANCE</p>
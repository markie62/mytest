<title><?php echo $title;?></title>
<p>USA</p>
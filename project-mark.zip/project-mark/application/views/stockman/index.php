<title><?php echo $title;?></title>

stockman